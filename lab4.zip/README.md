# Lab4
In Lab 4 I used AJAX to generate an HTML page and then populate it with JSON data. For part one I created the JSON document. Semantic tags were used to indace what each element was. This data was then read into the document upon clicking on the cd picture. An HTML framework for the data was generated as well. A neat extra I added was the ability to handle data sets containing more than four songs. The code is smart enough to create more rows on the page. If I had more time/less tests this week, I would have loved to create a more dynamic program that would populate column titles with keys in the JSON file.

[Repository Link](https://github.com/rickrizzo/Lab4 "Lab 4")
